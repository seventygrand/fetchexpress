from selenium import webdriver
import os
import time
import keyboard


def show_hacx_screen():
    hacx_logo = """


hhhhhhh                                                                      
h:::::h                                                                      
h:::::h                                                                      
h:::::h                                                                      
 h::::h hhhhh         aaaaaaaaaaaaa      ccccccccccccccccxxxxxxx      xxxxxxx
 h::::hh:::::hhh      a::::::::::::a   cc:::::::::::::::c x:::::x    x:::::x 
 h::::::::::::::hh    aaaaaaaaa:::::a c:::::::::::::::::c  x:::::x  x:::::x  
 h:::::::hhh::::::h            a::::ac:::::::cccccc:::::c   x:::::xx:::::x   
 h::::::h   h::::::h    aaaaaaa:::::ac::::::c     ccccccc    x::::::::::x    
 h:::::h     h:::::h  aa::::::::::::ac:::::c                  x::::::::x     
 h:::::h     h:::::h a::::aaaa::::::ac:::::c                  x::::::::x     
 h:::::h     h:::::ha::::a    a:::::ac::::::c     ccccccc    x::::::::::x    
 h:::::h     h:::::ha::::a    a:::::ac:::::::cccccc:::::c   x:::::xx:::::x   
 h:::::h     h:::::ha:::::aaaa::::::a c:::::::::::::::::c  x:::::x  x:::::x  
 h:::::h     h:::::h a::::::::::aa:::a cc:::::::::::::::c x:::::x    x:::::x 
 hhhhhhh     hhhhhhh  aaaaaaaaaa  aaaa   ccccccccccccccccxxxxxxx      xxxxxxx







    """
    os.system("clear" if os.name == "posix" else "cls")
    print(hacx_logo)


def main():
    show_hacx_screen()
    print("press space bar four times to start hacx secure browser")
    browser_opened = False
    while True:
        if keyboard.is_pressed("space") and not browser_opened:
            os.system("clear" if os.name == "posix" else "cls")
            print("opening hacx secure browser...")
            try:
                driver = webdriver.Chrome()
                driver.get("https://fetchexpress.netlify.app/")
                print("hacx secure browser is now open.")
                browser_opened = True
            except Exception as e:
                print(f"error: {e}")
                input("an error occurred. press enter to continue...")
                break
        time.sleep(0.1)


if __name__ == "__main__":
    main()
