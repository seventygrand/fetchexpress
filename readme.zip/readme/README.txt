﻿HOW TO UPLOAD: To upload, friend seventygrand on discord and then send a google drive link containing your file.

HOW TO TAKE DOWN: Same steps as how to upload, friend seventygrand and then tell the file that needs to be removed and why.
